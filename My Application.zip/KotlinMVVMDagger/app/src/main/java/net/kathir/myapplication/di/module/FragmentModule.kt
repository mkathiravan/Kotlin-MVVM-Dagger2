package net.kathir.myapplication.di.module

import dagger.Module
import dagger.android.ContributesAndroidInjector

@Module
abstract class FragmentModule
{
    @ContributesAndroidInjector(modules = [FragmentViewModelProvider::class])
    abstract fun bindListRepoFragment(): ListRepoFragment
}
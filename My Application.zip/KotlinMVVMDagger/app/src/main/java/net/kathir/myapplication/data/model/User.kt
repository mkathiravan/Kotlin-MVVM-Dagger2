package net.kathir.myapplication.data.model

class User(val login: String)